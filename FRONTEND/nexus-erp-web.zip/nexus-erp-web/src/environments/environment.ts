export const environment = {
     production: false,
  apiUrl: 'https://davidguijarro.com.es/tfg/BACKEND/public/index.php/api',
  mediaUrl: 'https://davidguijarro.com.es/tfg/BACKEND/public/',
  appUrl: 'https://davidguijarro.com.es/tfg'
};
  
